# flutter_lib

A new flutter module project.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).


flutter android ios google hybrid方案

需要flutter最新版1.2

或者使用dev1.19版也行

其它版本不确定是否支持hybrid