import 'package:flutter/material.dart';
import 'package:flutter_lib/model/category.dart';

class SubCategoryViewModel {
  List<Category> categorysItems;

  SubCategoryViewModel({this.categorysItems});


}
