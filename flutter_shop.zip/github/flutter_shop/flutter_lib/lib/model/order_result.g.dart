// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_result.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OrderResult _$OrderResultFromJson(Map<String, dynamic> json) {
  return OrderResult(orderId: json['orderId'] as String);
}

Map<String, dynamic> _$OrderResultToJson(OrderResult instance) =>
    <String, dynamic>{'orderId': instance.orderId};
