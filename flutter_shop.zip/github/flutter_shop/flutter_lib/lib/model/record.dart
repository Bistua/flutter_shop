class Record {
  String name;
  String status;
  String time;

  Record({
    this.name,
    this.status,
    this.time,
  });
}
