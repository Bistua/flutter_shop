class MineOrderTab {
  String tabName;
  String tabDescribe;

  MineOrderTab(this.tabName, this.tabDescribe);
}
