class Comment {
  String avator;
  String name;
  double star;
  String time;
  String comment;

  Comment({this.avator, this.name, this.star, this.time, this.comment});
}
