import 'package:flutter/material.dart';

class Rank {
  Color color;
  String name;
  String xiaofei;
  double fanli;

  Rank(
      {this.color,
      this.name,
        this.xiaofei,
        this.fanli});
}