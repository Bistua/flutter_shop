class Collection {
  String name;
  String image;
  String price;

  Collection({
    this.name,
    this.image,
    this.price,
  });
}
